from telethon import events, Button
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    inline_buttons = [
        [Button.inline("PANEL CREATE ACCOUNT", "menu")],
        [Button.url("TELEGRAM GROUP", "https://t.me/myridtunnel"),
         Button.url("ORDER SCRIPT", "https://t.me/kytxz")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))

    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except Exception as e:
            await event.reply(f"Akses Ditolak: {str(e)}")
    elif val == "true":
        try:
            ssh = subprocess.check_output('cat /etc/ssh/.ssh.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vmess = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vless = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            trojan = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            namaos = subprocess.check_output('cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed \'s/=//g\' | sed \'s/PRETTY_NAME//g\'', shell=True).decode("ascii").strip()
            ipsaya = subprocess.check_output('curl -s ipv4.icanhazip.com', shell=True).decode("ascii").strip()
            city = subprocess.check_output('cat /etc/xray/city', shell=True).decode("ascii").strip()

            msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
🐾🕊️ PREMIUM PANEL MENU 🕊️🐾
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» OS     :** `{namaos.strip().replace('"','')}`
🔰 **» CITY   :** `{city.strip()}`
🔰 **» IP VPS :** `{ipsaya.strip()}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
            await event.respond(msg, buttons=inline_buttons)
        except Exception as e:
            await event.respond(f"Error saat memproses data: {str(e)}")
