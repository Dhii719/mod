Tentu, berikut ini adalah bagian dari skrip yang telah disesuaikan setelah menghapus referensi `DOMAIN`:

```python
import time
import subprocess
import requests
from kyt import *
from telethon import events, Button

@bot.on(events.CallbackQuery(data=b'reboot'))
async def rebooot(event):
    async def rebooot_(event):
        cmd = 'reboot'
        await event.edit("Processing.")
        await asyncio.sleep(1)
        await event.edit("Processing..")
        await asyncio.sleep(1)
        await event.edit("Processing...")
        await asyncio.sleep(1)
        await event.edit("Processing....")
        await asyncio.sleep(1)
        await event.edit("`Processing Restart Service Server...`")
        await asyncio.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        subprocess.check_output(cmd, shell=True)
        await event.edit("""
**» REBOOT SERVER**
**» 🤖@myridtunnel**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await rebooot_(event)
    else:
        await event.answer("Access Denied", alert=True)


@bot.on(events.CallbackQuery(data=b'resx'))
async def resx(event):
    async def resx_(event):
        cmd = 'systemctl restart xray | systemctl restart nginx | systemctl restart haproxy | systemctl restart server | systemctl restart client'
        subprocess.check_output(cmd, shell=True)
        await event.edit("Processing.")
        await asyncio.sleep(1)
        await event.edit("Processing..")
        await asyncio.sleep(1)
        await event.edit("Processing...")
        await asyncio.sleep(1)
        await event.edit("Processing....")
        await asyncio.sleep(1)
        await event.edit("`Processing Restart Service Server...`")
        await asyncio.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("""
```Processing... 100%\n█████████████████████████ ```
**» Restarting Service Done**
**» 🤖@IlhamStore23**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await resx_(event)
    else:
        await event.answer("Access Denied", alert=True)


@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest(event):
    async def speedtest_(event):
        cmd = 'speedtest-cli --share'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        await asyncio.sleep(1)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        await event.respond(f"""
**
{z}
**
**» 🤖@myridtunnel**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await speedtest_(event)
    else:
        await event.answer("Access Denied", alert=True)


@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
    async def backup_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Input Email:**')
            user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_input = user_msg.message.raw_text.strip()
        
        cmd = f'printf "%s\n" "{user_input}" | bot-backup'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: