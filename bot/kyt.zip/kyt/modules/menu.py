import subprocess
import asyncio
from kyt import *
from telethon import events, Button

# Event handler untuk pesan baru dengan pola .menu atau /menu
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
async def handle_menu(event):
    await menu(event)

# Event handler untuk callback dengan data b'menu'
@bot.on(events.CallbackQuery(data=b'menu'))
async def handle_menu_callback(event):
    await menu(event)

# Fungsi untuk menampilkan menu utama
async def menu(event):
    inline_buttons = [
        [Button.inline("SSH OVPN MANAGER", "ssh")],
        [Button.inline("VMESS MANAGER", "vmess"), Button.inline("VLESS MANAGER", "vless")],
        [Button.inline("TROJAN MANAGER", "trojan"), Button.inline("SHDWSK MANAGER", "shadowsocks")],
        [Button.inline("CHECK VPS INFO", "info"), Button.inline("OTHER SETTING", "setting")],
        [Button.inline("‹ Back Menu ›", "start")]
    ]

    try:
        sender = await event.get_sender()
        user_id = str(sender.id)
        
        # Memeriksa validitas pengguna berdasarkan ID
        if valid(user_id) != "true":
            await event.answer("Access Denied", alert=True)
            return
        
        # Mengambil informasi dari server
        commands = {
            "ssh": 'cat /etc/ssh/.ssh.db | grep "###" | wc -l',
            "vmess": 'cat /etc/vmess/.vmess.db | grep "###" | wc -l',
            "vless": 'cat /etc/vless/.vless.db | grep "###" | wc -l',
            "trojan": 'cat /etc/trojan/.trojan.db | grep "###" | wc -l',
            "shadowsocks": 'echo "Not implemented yet"',  # Ganti dengan perintah sesuai dengan kebutuhan
            "info": 'curl -s ipv4.icanhazip.com',
            "setting": 'echo "Other settings placeholder"'
        }
        
        # Memproses setiap perintah untuk mengambil hasilnya
        results = {}
        for key, cmd in commands.items():
            try:
                output = await run_command(cmd)
                results[key] = output.strip()
            except Exception as e:
                results[key] = f"Error: {str(e)}"

        # Menampilkan informasi yang dikumpulkan dalam format pesan
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ ADMIN PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» IP VPS :** `{results.get("info", 'Error fetching IP')}`
**» Total Account Created:** 

**» 🚀SSH OVPN    :** `{results.get("ssh", 'Error fetching SSH accounts')}` __account__
**» 🎭XRAY VMESS  :** `{results.get("vmess", 'Error fetching VMESS accounts')}` __account__
**» 🗼XRAY VLESS  :** `{results.get("vless", 'Error fetching VLESS accounts')}` __account__
**» 🎯XRAY TROJAN :** `{results.get("trojan", 'Error fetching Trojan accounts')}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        await event.edit(msg, buttons=inline_buttons)
    
    except Exception as ex:
        await event.respond(f"Error: {str(ex)}")

# Fungsi untuk menjalankan perintah shell dan mengembalikan outputnya
async def run_command(cmd):
    process = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    stdout, stderr = await process.communicate()
    if stderr:
        raise RuntimeError(stderr.decode().strip())
    return stdout.decode().strip()

# Jalankan bot
bot.run_until_disconnected()
