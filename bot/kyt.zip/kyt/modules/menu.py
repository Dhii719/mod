from kyt import *

# Fungsi untuk menangani pembuatan akun VMESS
async def create_vmess_account():
    # Logika untuk membuat akun VMESS
    # Contoh: subprocess atau panggilan ke modul lain untuk membuat akun
    return "Akun VMESS berhasil dibuat!"

# Fungsi untuk menangani pembuatan akun Trojan
async def create_trojan_account():
    # Logika untuk membuat akun Trojan
    # Contoh: subprocess atau panggilan ke modul lain untuk membuat akun
    return "Akun Trojan berhasil dibuat!"

# Fungsi untuk menangani pembuatan akun VLESS
async def create_vless_account():
    # Logika untuk membuat akun VLESS
    # Contoh: subprocess atau panggilan ke modul lain untuk membuat akun
    return "Akun VLESS berhasil dibuat!"

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" SSH MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"),
         Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"),
         Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"),
         Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start"),
         Button.inline(" CS VIRTUAL ","csvirtual")]  # Tombol CS Virtual ditambahkan di sini
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))

    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
    elif val == "true":
        sh = 'cat /etc/ssh/.ssh.db | grep "###" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")

        vm = 'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")

        vl = 'cat /etc/vless/.vless.db | grep "###" | wc -l'
        vls = subprocess.check_output(vl, shell=True).decode("ascii")

        tr = 'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
        trj = subprocess.check_output(tr, shell=True).decode("ascii")

        sdss = "cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii").strip().replace('"', '')

        ipvps = "curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii").strip()

        citsy = "cat /etc/xray/city"
        city = subprocess.check_output(citsy, shell=True).decode("ascii").strip()

        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
     **🇮🇩🇮🇩 baimstore 🇮🇩🇮🇩**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS     :** `{namaos}`
**» CITY :** `{city}`
**» DOMAIN :** `{DOMAIN}`
**» IP VPS :** `{ipsaya}`
━━━━━━━━━━━━━━━━━━━━━━━ 
**» 🌹Total Account Created 🌹** 
**» ⚠️SSH OVPN    :** `{ssh}` __account__
**» ⚠️XRAY VMESS  :** `{vms}` __account__
**» ⚠️XRAY VLESS  :** `{vls}` __account__
**» ⚠️XRAY TROJAN :** `{trj}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""

        await event.edit(msg, buttons=inline)

@bot.on(events.CallbackQuery(data=b'csvirtual'))
async def cs_virtual(event):
    # Menangani event ketika tombol CS Virtual ditekan
    try:
        await event.answer("Silakan pilih jenis akun yang ingin Anda buat:")
        # Menampilkan tombol-tombol untuk jenis akun yang bisa dibuat
        await event.edit(buttons=[
            [Button.inline(" VMESS ","create_vmess")],
            [Button.inline(" VLESS ","create_vless")],
            [Button.inline(" TROJAN ","create_trojan")],
            [Button.inline(" ‹ Back Menu › ","menu")]  # Tombol kembali ke menu utama
        ])
    except Exception as e:
        print(f"Error: {str(e)}")

@bot.on(events.CallbackQuery(data=b'create_vmess'))
async def create_vmess(event):
    # Menangani pembuatan akun VMESS jika tombol VMESS ditekan
    try:
        result = await create_vmess_account()
        await event.answer(result)
    except Exception as e:
        print(f"Error creating VMESS account: {str(e)}")

@bot.on(events.CallbackQuery(data=b'create_trojan'))
async def create_trojan(event):
    # Menangani pembuatan akun Trojan jika tombol Trojan ditekan
    try:
        result = await create_trojan_account()
        await event.answer(result)
    except Exception as e:
        print(f"Error creating Trojan account: {str(e)}")

@bot.on(events.CallbackQuery(data=b'create_vless'))
async def create_vless(event):
    # Menangani pembuatan akun VLESS jika tombol VLESS ditekan
    try:
        result = await create_vless_account()
        await event.answer(result)
    except Exception as e:
        print(f"Error creating VLESS account: {str(e)}")
