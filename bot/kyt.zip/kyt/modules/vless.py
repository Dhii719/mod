import re
import subprocess
import asyncio
from telethon import events, Button

@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
    async def create_vless_(event):
        async with bot.conversation(chat) as conv:
            await event.respond('**Username:**')
            user = (await conv.get_response()).raw_text.strip()
            
            await event.respond("**Quota (GB):**")
            pw = (await conv.get_response()).raw_text.strip()
            
            await event.respond("**Choose Expiry Day:**", buttons=[
                [Button.inline("3 Day", "3"), Button.inline("7 Day", "7")],
                [Button.inline("30 Day", "30"), Button.inline("60 Day", "60")]
            ])
            exp = (await conv.wait_event(events.CallbackQuery)).data.decode("ascii")
        
        await event.edit("`Processing Create Premium Account`")
        await asyncio.sleep(3)
        cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | addvless'
        
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**User Already Exists**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            x = re.findall("vless://(.*?) ", a)
            uuid = x[0].strip()
            
            msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Vless Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Username  :** `{user}`
**» User Quota :** `{pw} GB`
**» User ID    :** `{uuid}`
**» Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━**
**» Link VLESS : **
`{x[0]}`
**━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)
    
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    
    if a == "true":
        await create_vless_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'cek-vless'))
async def cek_vless(event):
    async def cek_vless_(event):
        cmd = 'bot-cek-vless'.strip()
        try:
            z = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: {e}")
            return
        
        await event.respond(f"""
{z}

**Shows Logged In Users Vless**
""")
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    
    if a == "true":
        await cek_vless_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
    async def delete_vless_(event):
        async with bot.conversation(chat) as conv:
            await event.respond('**Username:**')
            user = (await conv.get_response()).raw_text.strip()
        
        cmd = f'printf "%s\n" "{user}" | delvless'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**User Not Found**")
        else:
            msg = f"""**Successfully Deleted**"""
            await event.respond(msg)
    
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    
    if a == "true":
        await delete_vless_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
    async def trial_vless_(event):
        async with bot.conversation(chat) as conv:
            await event.respond("**Choose Expiry Minutes:**", buttons=[
                [Button.inline("10 Menit", "10"), Button.inline("15 Menit", "15")],
                [Button.inline("30 Menit", "30"), Button.inline("60 Menit", "60")]
            ])
            exp = (await conv.wait_event(events.CallbackQuery)).data.decode("ascii")
        
        await event.edit("`Processing Create Premium Account`")
        await asyncio.sleep(3)
        cmd = f'printf "%s\n" "{exp}" | trialvless'
        
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**User Already Exists**")
        else:
            x = re.findall("vless://(.*?) ", a)
            uuid = x[0].strip()
            
            msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Vless Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» User ID    :** `{uuid}`
**» Expired Until :** `{exp} Minutes`
**━━━━━━━━━━━━━━━━━**
**» Link VLESS : **
`{x[0]}`
**━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)
    
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    
    if a == "true":
        await trial_vless_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
    async def vless_(event):
        inline = [
            [Button.inline("TRIAL VLESS", "trial-vless"), Button.inline("CREATE VLESS", "create-vless")],
            [Button.inline("CHECK VLESS", "cek-vless"), Button.inline("DELETE VLESS", "delete-vless")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        msg = """
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ VLESS MANAGER ??️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        await event.edit(msg, buttons=inline)
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    
    if a == "true":
        await vless_(event)
    else:
        await event.answer("Access Denied", alert=True)
