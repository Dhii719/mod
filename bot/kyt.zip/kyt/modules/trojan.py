import subprocess
import time
import requests
import re
from telethon import events, Button

@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
    async def create_trojan_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user_msg = await user_conv.get_response()
            user = user_msg.raw_text.strip()

        async with bot.conversation(chat) as quota_conv:
            await event.respond("**Quota (GB):**")
            quota_msg = await quota_conv.get_response()
            pw = quota_msg.raw_text.strip()

        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Day**",
                                buttons=[[Button.inline(" 3 Day ", "3"),
                                          Button.inline(" 7 Day ", "7")],
                                         [Button.inline(" 30 Day ", "30"),
                                          Button.inline(" 60 Day ", "60")]])
            exp_msg = await exp_conv.wait_event(events.CallbackQuery)
            exp = exp_msg.data.decode("ascii")

        try:
            await event.edit("`Processing...`")
            time.sleep(2)  # Simulasi proses
            await event.edit("`Wait.. Setting up an Account`")

            cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | addtr'
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            if "User Already Exist" in result.stdout:
                await event.respond("**User Already Exist**")
            else:
                today = DT.date.today()
                later = today + DT.timedelta(days=int(exp))
                b = re.findall("trojan://(.*)", result.stdout)
                domain = re.search("@(.*?):", b[0]).group(1)
                uuid = re.search("trojan://(.*?)@", b[0]).group(1)
                msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Trojan Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks     :** `{user}`
**» Host Server :** `{domain}`
**» User Quota  :** `{pw} GB`
**» Port DNS    :** `443, 53`
**» port TLS    :** `222-1000`
**» User ID     :** `{uuid}`
**━━━━━━━━━━━━━━━━━**
**» Link WS    :** 
`{b[0].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Link GRPC  :** 
`{b[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Format OpenClash : https://{domain}:81/trojan-{user}.txt
**━━━━━━━━━━━━━━━━━**
**Expired Until:** `{later}`
**» 🤖@IlhamStore23**
"""
                await event.respond(msg)
        except Exception as e:
            await event.respond(f"Error: {str(e)}")

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
    async def cek_trojan_(event):
        cmd = 'bot-cek-tr'.strip()  # Pastikan ini adalah perintah yang benar sesuai dengan pengaturan Anda
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            await event.respond(result.stdout, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: {e.output}")

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await cek_trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
    async def trial_trojan_(event):
        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Minutes**",
                                buttons=[[Button.inline(" 10 Menit ", "10"),
                                          Button.inline(" 15 Menit ", "15")],
                                         [Button.inline(" 30 Menit ", "30"),
                                          Button.inline(" 60 Menit ", "60")]])
            exp_msg = await exp_conv.wait_event(events.CallbackQuery)
            exp = exp_msg.data.decode("ascii")

        try:
            await event.edit("`Processing...`")
            time.sleep(2)  # Simulasi proses
            await event.edit("`Wait.. Setting up an Account`")

            cmd = f'printf "%s\n" "{exp}" | trialtr'
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            if "User Already Exist" in result.stdout:
                await event.respond("**User Already Exist**")
            else:
                b = re.findall("trojan://(.*)", result.stdout)
                remarks = re.search("#(.*)", b[0]).group(1)
                domain = re.search("@(.*?):", b[0]).group(1)
                uuid = re.search("trojan://(.*?)@", b[0]).group(1)
                msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Trojan Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks     :** `{remarks}`
**» Host Server :** `{domain}`
**» User Quota  :** `Unlimited`
**» Port DNS    :** `443, 53`
**» port TLS    :** `222-1000`
**» Path Trojan :** `(/multi path)/trojan-ws`
**» User ID     :** `{uuid}`
**━━━━━━━━━━━━━━━━━**
**» Link WS    :** 
`{b[0].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Link GRPC  :** 
`{b[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{exp} Minutes`
**» 🤖@IlhamStore23**
"""
                await event.respond(msg)
        except Exception as e:
            await event.respond(f"Error: {str(e)}")

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
    async def delete_trojan_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user_msg = await user_conv.get_response()
            user = user_msg.raw_text.strip()

        cmd = f'printf "%s\n" "{user}" | deltr'
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            if "User Not Found" in result.stdout:
                await event.respond("**User Not Found**")
            else:
                await event.respond("**Successfully Deleted**")
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: {e.output}")

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await delete_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
    async def trojan_(event):
        inline_buttons = [
            [Button.inline(" TRIAL TROJAN ", "trial-trojan"),
             Button.inline(" CREATE TROJAN ", "create-trojan")],
            [Button.inline(" CHECK TROJAN ", "cek-trojan"),
             Button.inline(" DELETE TROJAN ", "delete-trojan")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]

        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ TROJAN MANAGER 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Service:** `TROJAN`
🔰 **» Hostname/IP:** `Your Hostname/IP`
🔰 **» ISP:** `{z["isp"]}`
🔰 **» Country:** `{z["country"]}`
🤖 **» @IlhamStore23**
━━━━━━━━━━━━━━━━━━━━━━━━━━━
