import subprocess
import time
from kyt import *
from telethon import events, Button

# Menangani event callback dengan data 'info'
@bot.on(events.CallbackQuery(data=b'info'))
async def info_vps(event):
    async def info_vps_():
        try:
            cmd = 'bot-vps-info'.strip()
            await event.edit("`Processing Info Service Server...`")
            time.sleep(2)  # Waktu simulasi proses
            output = subprocess.check_output(cmd, shell=True, universal_newlines=True)
            await event.edit(f"```{output}```\n**🤖 @myridtunnel**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except Exception as e:
            await event.respond(f"Error: {str(e)}")

    # Memeriksa validitas pengguna berdasarkan ID
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await info_vps_()
    else:
        await event.answer("Access Denied", alert=True)
