from telethon import events, Button
from adminbot import *  # Pastikan Anda mengimpor fungsi-fungsi yang diperlukan dari adminbot

@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
    async def create_trojan_(event):
        sender = await event.get_sender()
        async with bot.conversation(event.chat_id) as conv:
            await event.respond('**Username:**')
            user_resp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user_resp.message.raw_text.strip()
            
            await event.respond("**Limit GB:**")
            pw_resp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = pw_resp.message.raw_text.strip()
            
            await event.respond("**Choose Expiry Day:**",
                                buttons=[
                                    [Button.inline("3 days", b"3"), Button.inline("7 days", b"7")],
                                    [Button.inline("30 days", b"30"), Button.inline("60 days", b"60")]
                                ])
            exp_resp = await conv.wait_event(events.CallbackQuery)
            exp = exp_resp.data.decode("ascii")
            
        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | addtr-bot'
        
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond(f"**User already exists**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            b = [x.group() for x in re.finditer("trojan://(.*)", a)]
            print(b)
            domain = re.search("@(.*?):", b[0]).group(1)
            uuid = re.search("trojan://(.*?)@", b[0]).group(1)
            
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
** xʀᴀʏ/ᴛʀᴏᴊᴀɴ ᴀᴄᴄᴏᴜɴᴛ **
**◇━━━━━━━━━━━━━━━━━◇**
**» ʀᴇᴍᴀʀᴋ     :** `{user}`
**» ᴜsᴇʀ ʟɪᴍɪᴛ ɢʙ  :** `{pw} GB`
**» ᴘᴏʀᴛ ᴅɴs    :** `443, 53`
**» ᴘᴏʀᴛ ᴛʟs    :** `222-1000`
**» ᴜsᴇʀ ɪᴅ     :** `{uuid}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ʟɪɴᴋ ᴡs    :** `{b[0].replace(" ", "")}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ʟɪɴᴋ ɢʀᴘᴄ  :** `{b[1].replace(" ", "")}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ʟɪɴᴋ ᴊsᴏɴ  :** `https://${DOMAIN}:81/trojan-{user}.txt`
**◇━━━━━━━━━━━━━━━━━◇**
**ᴇxᴘɪʀᴇᴅ ᴜɴᴛɪʟ:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» 🤖@rizyulvpn**
"""
            await event.respond(msg)
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
    async def cek_trojan_(event):
        cmd = 'bot-cek-tr'.strip()
        try:
            x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: {e.output}")
        else:
            z = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"""
{z}

**Shows logged in users Trojan**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await cek_trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
    async def trial_trojan_(event):
        cmd = f'printf "%s\n" | trialtr-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: {e.output}")
        else:
            b = [x.group() for x in re.finditer("trojan://(.*)", a)]
            print(b)
            remarks = re.search("#(.*)", b[0]).group(1)
            domain = re.search("@(.*?):", b[0]).group(1)
            uuid = re.search("trojan://(.*?)@", b[0]).group(1)
            
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
** xʀᴀʏ/ᴛʀᴏᴊᴀɴ ᴀᴄᴄᴏᴜɴᴛ **
**◇━━━━━━━━━━━━━━━━━◇**
**» ʀᴇᴍᴀʀᴋs     :** `{remarks}`
**» ʜᴏsᴛ sᴇʀᴠᴇʀ :** `{domain}`
**» ᴜsᴇʀ ʟɪᴍɪᴛ ɢʙ  :** `Unlimited`
**» ᴘᴏʀᴛ ᴅɴs    :** `443, 53`
**» ᴘᴏʀᴛ ᴛʟs    :** `222-1000`
**» ᴜsᴇʀ ɪᴅ     :** `{uuid}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ʟɪɴᴋ ᴡs    :** `{b[0].replace(" ", "")}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ʟɪɴᴋ ɢʀᴘᴄ  :** `{b[1].replace(" ", "")}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ʟɪɴᴋ ᴊsᴏɴ  :** `https://${DOMAIN}:81/trojan-{user}.txt`
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `60 Minutes`
**◇━━━━━━━━━━━━━━━━━◇**
**» 🤖@rizyulvpn**
"""
            await event.respond(msg)
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'renew-trojan'))
async def ren_trojan(event):
    async def ren_trojan_(event):
        sender = await event.get_sender()
        async with bot.conversation(event.chat_id) as conv:
            await event.respond('**Username:**')
            user_resp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user_resp.message.raw_text.strip()
            
            await event.respond("**Choose Expiry Day:**",
                                buttons=[
                                    [Button.inline("3 days", b"3"), Button.inline("7 days", b"7")],
                                    [Button.inline("30 days", b"30"), Button.inline("60 days", b"60")]
                                ])
            exp_resp = await conv.wait_event(events.CallbackQuery)
            exp = exp_resp.data.decode("ascii")
            
        cmd = f'printf "%s\n" "{user}" {exp} | renewtr-bot'
        
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: {e.output}")
        else:
            msg = f"""**Successfully renewed {user} for {exp}**"""
            await event.respond(msg)
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await ren_trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
    async def delete_trojan_(event):
        sender = await event.get_sender()
        async with bot.conversation(event.chat_id) as conv:
            await event.respond('**Username:**')
            user_resp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user_resp.message.raw_text.strip()
        
        cmd = f'printf "%s\n" "{user}" | deltr-bot'
        
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: {e.output}")
        else:
            msg = f"""**Successfully deleted**"""
            await event.respond(msg)
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await delete_trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
    async def trojan_(event):
        inline = [
            [Button.inline("Trial TR", b"trial-trojan")],
            [Button.inline("Create TR", b"create-trojan"), Button.inline("Check TR", b"cek-trojan")],
            [Button.inline("Delete TR", b"delete-trojan"), Button.inline("Renew TR", b"renew-trojan")],
            [Button.inline("‹ Main Menu ›", b"menu")]
        ]
        
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**⚜️           Trojan Manager              ⚜️**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰Service:** `TROJAN`
🔰Domain :** `{DOMAIN}`
🔰ISP:** `{z["isp"]}`
🔰Country:** `{z["country"]}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        await event.edit(msg, buttons=inline)
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)
