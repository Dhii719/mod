from adminbot import *
import subprocess
import re
import datetime as DT
import requests

@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
    async def create_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text.strip()
        async with bot.conversation(chat) as pw:
            await event.respond("**Limit GB:**")
            pw = await pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = pw.raw_text.strip()
        async with bot.conversation(chat) as exp:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline("3 days", "3"),
                 Button.inline("7 days", "7")],
                [Button.inline("30 days", "30"),
                 Button.inline("60 days", "60")]
            ])
            exp = await exp.wait_event(events.CallbackQuery)
            exp = exp.data.decode("ascii")
        
        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | addtr'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond("**User already exists**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            b = re.findall(r"trojan://(.*)", a)
            domain = re.search("@(.*?):", b[0]).group(1)
            uuid = re.search("trojan://(.*?)@", b[0]).group(1)
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**  Xray/Trojan Account **
**◇━━━━━━━━━━━━━━━━━◇**
**» Remark     :** `{user}`
**» User Limit GB  :** `{pw} GB`
**» DNS Port    :** `443, 53`
**» TLS Port    :** `222-1000`
**» User ID     :** `{uuid}`
**◇━━━━━━━━━━━━━━━━━◇**
**» WS Link    :** 
`{b[0].replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━◇**
**» GRPC Link  :** 
`{b[1].replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━◇**
**» JSON Link  :** `https://${DOMAIN}:81/trojan-{user}.txt`
**◇━━━━━━━━━━━━━━━━━◇**
**Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» 🤖@rizyulvpn**
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
    async def cek_trojan_(event):
        cmd = 'bot-cek-tr'.strip()
        try:
            z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: {e}")
        else:
            await event.respond(f"""
{z}

**Shows Logged in Users Trojan**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await cek_trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
    async def trial_trojan_(event):
        cmd = f'printf "%s\n" | trialtr-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond("**User already exists**")
        else:
            b = re.findall(r"trojan://(.*)", a)
            remarks = re.search("#(.*)", b[0]).group(1)
            domain = re.search("@(.*?):", b[0]).group(1)
            uuid = re.search("trojan://(.*?)@", b[0]).group(1)
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**  Xray/Trojan Account **
**◇━━━━━━━━━━━━━━━━━◇**
**» Remarks     :** `{remarks}`
**» Host Server :** `{domain}`
**» User Limit GB  :** `Unlimited`
**» DNS Port    :** `443, 53`
**» TLS Port    :** `222-1000`
**» User ID     :** `{uuid}`
**◇━━━━━━━━━━━━━━━━━◇**
**» WS Link    :** 
`{b[0].replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━◇**
**» GRPC Link  :** 
`{b[1].replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━◇**
**» JSON Link  :** `https://${DOMAIN}:81/trojan-{user}.txt`
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `60 Minutes`
**◇━━━━━━━━━━━━━━━━━◇**
**» 🤖@rizyulvpn**
"""
            await event.respond(msg)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'renew-trojan'))
async def ren_trojan(event):
    async def ren_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text.strip()
        async with bot.conversation(chat) as exp:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline("3 days", "3"),
                 Button.inline("7 days", "7")],
                [Button.inline("30 days", "30"),
                 Button.inline("60 days", "60")]
            ])
            exp = await exp.wait_event(events.CallbackQuery)
            exp = exp.data.decode("ascii")
        cmd = f'printf "%s\n" "{user}" {exp} | renewtr-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond("**User not found**")
        else:
            msg = f"**Successfully renewed {user} {exp}**"
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await ren_trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
    async def delete_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text.strip()
        cmd = f'printf "%s\n" "{user}" | deltr-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond("**User not found**")
        else:
            msg = "**Successfully deleted**"
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await delete_trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
    async def trojan_(event):
        inline = [
            [Button.inline("Trial Trojan", "trial-trojan")],
            [Button.inline("Create Trojan", "create-trojan"),
             Button.inline("Check Trojan", "cek-trojan")],
            [Button.inline("Delete Trojan", "delete-trojan"),
             Button.inline("Renew Trojan", "renew-trojan")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**⚜️           Trojan Manager              ⚜️**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰Service:** `TROJAN`
🔰Domain :** `{DOMAIN}`
🔰ISP:** `{z["isp"]}`
🔰Country:** `{z["country"]}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)
